package TicketCounter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DAO {
	Connecting c=new Connecting();
	public PreparedStatement getps(String q) throws SQLException, ClassNotFoundException
	{
		Connection con=c.getConnect();
		PreparedStatement ps=con.prepareStatement(q);
		ps.executeUpdate();
		return ps;
		
	}
	public ResultSet getrs(String q) throws SQLException, ClassNotFoundException
	{
		Connection con=c.getConnect();
		Statement stmt=con.createStatement();
		ResultSet rs=stmt.executeQuery(q);
		
		return rs;
	}
}
