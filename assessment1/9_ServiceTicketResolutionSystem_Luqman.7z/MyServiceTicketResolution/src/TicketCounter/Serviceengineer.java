package TicketCounter;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/Serviceengineer")
public class Serviceengineer extends HttpServlet {
	private static final long serialVersionUID = 1L;
       EndUserbean eb=new EndUserbean();
       Serviceengineerop seop=new Serviceengineerop();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		//TicketCounter.bean client=(TicketCounter.bean) request.getSession().getAttribute("client");
		//String uname=request.getParameter("uname");
		String uname=(String) request.getSession().getAttribute("uname");
		//out.println(uname);
		eb.setUsername(uname);
		String d="jkf";
		String v="sdf";
		String k=request.getParameter("tid");
		String s=request.getParameter("stat");
		String p=request.getParameter("Priority");
		 v=request.getParameter("value");
		 //d=request.getParameter("submit");
		 
		//String h=request.getParameter("param1");
		
		if(v.equals("Respond"))
		{
			String i="1";
			ArrayList<TicketCounter.EndUserbean> user=seop.respond(eb);
			HttpSession session = request.getSession();		
			session.setAttribute("users", user);
			session.setAttribute("ch",i);
			session.setAttribute("choice",uname);
			RequestDispatcher rd=request.getRequestDispatcher("/ServiceEngineerOutput.jsp");
			rd.forward(request, response);
		}
		else if(v.equals("Report"))
		{
			out.println(" "+v);
			String i="2";
				String[] Array=seop.report();
				HttpSession session=request.getSession();
				session.setAttribute("arr", Array);
				session.setAttribute("ch", i);
				RequestDispatcher rd=request.getRequestDispatcher("/ServiceEngineerOutput.jsp");
				rd.forward(request, response);
		}
		else if(v.equals("ReportSE"))
		{
			out.println(" "+v);
			String i="3";
				ArrayList<String> arr=seop.reportSE();
				HttpSession session=request.getSession();
				session.setAttribute("arr", arr);
				session.setAttribute("ch", i);
				RequestDispatcher rd=request.getRequestDispatcher("/ServiceEngineerOutput.jsp");
				rd.forward(request, response);
				
		}
		else if(v.equals("avgage"))
		{
			out.println(" "+v);
			String i="4";
				ArrayList<String> arr=seop.avgage(uname);
				HttpSession session=request.getSession();
				session.setAttribute("arr", arr);
				session.setAttribute("ch", i);
				RequestDispatcher rd=request.getRequestDispatcher("/ServiceEngineerOutput.jsp");
				rd.forward(request, response);
				
		}
		else if(v.equals("changestat"))
		{
			
			seop.changestat(k,s,eb);
			//out.println(k + " " + l + " "+ d);
		}
		else if(v.contentEquals("changepriority"))
		{
			seop.changeprio(k,p);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
