package TicketCounter;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Typecheck
 */
@WebServlet("/Typecheck")
public class Typecheck extends HttpServlet {
	private static final long serialVersionUID = 1L;
	bean client = new bean();
	LoginPurpose lp = new LoginPurpose();

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		String u=request.getParameter("username");
		String p=request.getParameter("password");
		String r = request.getParameter("submit");
		System.out.println(u+" "+p );
		//||u.equals("''")&&p.equals("''")
		if(u.equals("") && p.equals("")||u.equals("")||p.equals(""))
		{
			System.out.println("its null");
			out.println("<h3>Provide an input!</h3>");
			RequestDispatcher rd = request.getRequestDispatcher("/Login.jsp");
			rd.include(request, response);
		}
		else {
		if (r.equals("Register")) {

			client.setUsername(request.getParameter("username"));
			client.setPassword(request.getParameter("password"));
			int c = lp.reg_user(client);
			System.out.println(c);
			if (c == 0) {
				out.println("<h3>hi new user, u can try loggin in!</h3>");
				RequestDispatcher rd = request.getRequestDispatcher("/Login.jsp");
				rd.include(request, response);
			} else if (c == 1) {
				out.println("<h3>username already exists, please use other username!</h3>");
				RequestDispatcher rd = request.getRequestDispatcher("/Login.jsp");
				rd.include(request, response);
			} else if (c == 2) {
				out.println(
						"<h3>enter Proper Password!it must contain a number an alphabet in upper and lower Case and a special character!!!</h3>");
				RequestDispatcher rd = request.getRequestDispatcher("/Login.jsp");
				rd.include(request, response);
			}
		} else if (r.equals("Login")) {
			client.setUsername(request.getParameter("username"));
			client.setPassword(request.getParameter("password"));

			int v = lp.login(client);
			// System.out.println(v);
			if (v == 0) {
				out.println("<h3>invalid username/password!</h3>");
				RequestDispatcher rd = request.getRequestDispatcher("/Login.jsp");
				rd.include(request, response);
			} else {
				if (v == 1) {
					//System.out.println("hi SE!");
					request.setAttribute("client", client);

					HttpSession session = request.getSession();
					session.setAttribute("uname", client.getUsername());
					request.getRequestDispatcher("ServiceEngineer.jsp").forward(request, response);
				} else if (v == 2) {
					// out.println("hi SE!");
					//System.out.println("hi EU!");
					HttpSession session = request.getSession();
					request.setAttribute("client", client);
					session.setAttribute("uname", client.getUsername());
					request.getRequestDispatcher("EndUser.jsp").forward(request, response);
				}
			}
		}
		if (r.equals("Logout")) {
			//System.out.println("nope");
			RequestDispatcher rd = request.getRequestDispatcher("/Login.jsp");
			client.setUsername("nahi");
			//System.out.println("'"+client.getUsername()+"'");
			rd.forward(request, response);
		}
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
