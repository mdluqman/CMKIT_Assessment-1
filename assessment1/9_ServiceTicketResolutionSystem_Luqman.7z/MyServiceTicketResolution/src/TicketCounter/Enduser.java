package TicketCounter;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Enduser
 */
@WebServlet("/Enduser")
public class Enduser extends HttpServlet {
	EndUserbean Enduser =new EndUserbean();
	Enduserop op=new Enduserop();
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String username=(String) request.getSession().getAttribute("username");
		out.println(username);
		String val=request.getParameter("submit");
		String val1=request.getParameter("value");
		if(val==null)
		{
			val="hsss";
		}
		
		Enduser.setDept(request.getParameter("dept"));
		Enduser.setWs(request.getParameter("ws"));
		Enduser.setPriority(request.getParameter("priority"));
		//Enduser.setRcd(rcd);
		//Enduser.setSEid(seid);
		Enduser.setSubject(request.getParameter("subject"));
		//Enduser.setTid(tid);
		Enduser.setType(request.getParameter("type"));
		Enduser.setRed(request.getParameter("red"));
		
		if(val.equals("raiseticket"))
		{
			if(op.redv(Enduser))
			{
			String i="1";
			Enduser.setTid(op.gen());
			String x=op.assignTicket(Enduser,username);
			HttpSession session = request.getSession();
			session.setAttribute("y", x);
			session.setAttribute("choice", i);
			RequestDispatcher rd=request.getRequestDispatcher("/EndUserOutput.jsp");
			rd.forward(request, response);
			}
		else
		{
			out.println("invalid RequestEndDate");
			RequestDispatcher rd=request.getRequestDispatcher("/RaiseTicket.jsp");
			rd.forward(request, response);
		}
		}
		else if(val1.equals("viewticket"))
		{
			String i="2";
			ArrayList<TicketCounter.EndUserbean> user= op.veiwTickets(Enduser,username);
			HttpSession session = request.getSession();		
			session.setAttribute("users", user);
			session.setAttribute("choice",i);
			RequestDispatcher rd=request.getRequestDispatcher("/EndUserOutput.jsp");
			rd.forward(request, response);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
