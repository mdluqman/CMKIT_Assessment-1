package TicketCounter;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Random;

public class Enduserop {
	DAO co=new DAO();
	public String assignTicket(TicketCounter.EndUserbean Enduser,String username) {
		// TODO Auto-generated method stub
		ResultSet rs1=null,res1=null,res2=null;
		String flag="0";
		java.util.Date date=new java.util.Date();
		java.sql.Date sqlDate=new java.sql.Date(date.getTime());
		ArrayList<TicketCounter.EndUserbean> dao = new ArrayList<>();
		try {
			rs1=co.getrs("select seid,CHPTicketId from ServiceEngineerData where AreaOfExpertise='"+Enduser.getDept()+"'");
			int p;
					while(rs1.next()) {
			    						if(rs1.getString(2).equals("0"))
			    						{
			    							//p=rs1.getInt(2) + 1;
			    							//System.out.println(rs1.getString(1) + " " +rs1.getString(2)+" "+ p);
			    							PreparedStatement rs2 = co.getps("insert into TicketHolder values('"+rs1.getString(1)+"','"+Enduser.getTid()+"','"+Enduser.getDept()+"','New','"+Enduser.getPriority()+"','"+sqlDate+"','"+Enduser.getRed()+"',null,null,'"+username+"','"+Enduser.getSubject()+"','"+Enduser.getWs()+"')");
			    							PreparedStatement rs3 = co.getps("update ServiceEngineerData set  CHPTicketId='"+Enduser.getTid()+"' where seid='"+rs1.getString(1)+"'");
			    							flag="1";
			    							return flag;
			    						}
					}
				res1=co.getrs("select seid,TicketId,Priority from TicketHolder where dept='"+Enduser.getDept()+"' order by Priority asc , BeginDate desc");
				while(res1.next())
				{
					res2=co.getrs("select CHPTicketId,Pending from ServiceEngineerData where seid='"+res1.getString(1)+"'");
					res2.next();
					int j=res2.getInt(2)+1;
					int x=Integer.parseInt(res1.getString(3));
						if(x>=Integer.parseInt(Enduser.getPriority()) && j<8)
								{
							PreparedStatement rs2 = co.getps("insert into TicketHolder values('"+res1.getString(1)+"','"+Enduser.getTid()+"','"+Enduser.getDept()+"','Pending','"+Enduser.getPriority()+"','"+sqlDate+"','"+Enduser.getRed()+"',null,null,'"+username+"','"+Enduser.getSubject()+"','"+Enduser.getWs()+"')");
							PreparedStatement rs9 = co.getps("update ServiceEngineerData set Pending='"+j+"' where seid='"+res1.getString(1)+"'");
							
							flag="1";
							return flag;
								}
						else if(x<Integer.parseInt(Enduser.getPriority()) && j<=7)
						{
//							res2=co.getrs("select CHPTicketId from ServiceEngineerData where seid='"+res1.getString(1)+"'");
//							res2.next();
//							p=res2.getInt(1) + 1;
							String h=res2.getString(1);
							PreparedStatement rs2 = co.getps("insert into TicketHolder values('"+res1.getString(1)+"','"+Enduser.getTid()+"','"+Enduser.getDept()+"','New','"+Enduser.getPriority()+"','"+sqlDate+"','"+Enduser.getRed()+"',null,null,'"+username+"','"+Enduser.getSubject()+"','"+Enduser.getWs()+"')");
							PreparedStatement rs3 = co.getps("update ServiceEngineerData set CHPTicketId='"+Enduser.getTid()+"', Pending ='"+j+"' where seid='"+res1.getString(1)+"'");
							PreparedStatement rs4 = co.getps("update TicketHolder set Stats ='Waiting' where TicketId='"+h+"'");
							flag="1";
							return flag;
						}
				}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

	public String gen()
	{
		String x;
		final Random RANDOM = new Random();
		
	    String digits="0123456789";
		StringBuilder returnValue = new StringBuilder(5);
		String v="TKTID";
        for (int i = 0; i < 5; i++) {
        	returnValue.append(digits.charAt(RANDOM.nextInt(digits.length())));
        }
        x=returnValue.toString();
        x=v+x;
		return x;
	}

	public ArrayList<EndUserbean> veiwTickets(EndUserbean enduser, String username) {
		// TODO Auto-generated method stub
		ArrayList<TicketCounter.EndUserbean> dao = new ArrayList<>();
		try
		{
			ResultSet rs1=co.getrs("select * from TicketHolder where CustomerUsername='"+username+"'");
			while(rs1.next())
			{
				String bd = null;
				String cd =  null;
				
				// rs1.getDate(8).toString(),rs1.getDate(9).toString()
				if(rs1.getDate(8) == null) {
					bd = "";
				}
				if(rs1.getDate(9) == null) {
					cd = "";
				}
				if(rs1.getDate(8) == null && rs1.getDate(9) == null)
					dao.add(new TicketCounter.EndUserbean(rs1.getString(1),rs1.getString(2),rs1.getString(3),rs1.getString(4),rs1.getString(5),rs1.getDate(6).toString(),rs1.getDate(7).toString(), bd, cd,rs1.getString(10),rs1.getString(11),rs1.getString(12)));
				//System.out.println("'"+rs1.getString(10)+"' '"+rs1.getString(12)+"' ");
				else if(rs1.getDate(8) != null && rs1.getDate(9) == null)
					dao.add(new TicketCounter.EndUserbean(rs1.getString(1),rs1.getString(2),rs1.getString(3),rs1.getString(4),rs1.getString(5),rs1.getDate(6).toString(),rs1.getDate(7).toString(), rs1.getDate(8).toString(), cd,rs1.getString(10),rs1.getString(11),rs1.getString(12)));
				else if(rs1.getDate(8) != null && rs1.getDate(9) != null)
					dao.add(new TicketCounter.EndUserbean(rs1.getString(1),rs1.getString(2),rs1.getString(3),rs1.getString(4),rs1.getString(5),rs1.getDate(6).toString(),rs1.getDate(7).toString(), rs1.getDate(8).toString(),rs1.getDate(9).toString(),rs1.getString(10),rs1.getString(11),rs1.getString(12)));
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return dao;
	}

	public boolean redv(EndUserbean enduser) {
		// TODO Auto-generated method stub
		java.util.Date date=new java.util.Date();
		java.sql.Date now=new java.sql.Date(date.getTime());
		java.util.Date cd=null;
		try {
			cd = (java.util.Date) new SimpleDateFormat("yyyy-MM-dd").parse(enduser.getRed());
			if (cd.getYear() > now.getYear()) 
		    {
		        return true;
		    }
		    else if(cd.getYear() == now.getYear()) 
		    {
		    if (cd.getMonth() > now.getMonth()) {
		    return true;
		    } 
		    else if(cd.getMonth() == now.getMonth())
		    {
		    if (cd.getDate() >= now.getDate()) {
		        return true;
		    }
		    else
		    {
		        return false;
		    }
		    }


		    }

		   else{
		    return false;
		    }
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  

		    
		return false;
	}

}
