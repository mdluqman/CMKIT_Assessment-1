package TicketCounter;

import java.io.PrintWriter;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.regex.Pattern;

import javax.servlet.RequestDispatcher;

import com.mysql.jdbc.PreparedStatement;

public class LoginPurpose {
	DAO data = new DAO();
	int flag = 0;

	public ArrayList<TicketCounter.bean> login_auth(TicketCounter.bean client) {
		// TODO Auto-generated method stub
		ResultSet rs1 = null;
		ArrayList<TicketCounter.bean> dao = new ArrayList<>();
		try {
			rs1 = data.getrs("select * from Authentication");
			while (rs1.next()) {
				dao.add(new TicketCounter.bean(rs1.getString(1), rs1.getString(2), rs1.getString(3)));
				// System.out.println(rs1.getString(1)+" "+rs1.getString(2));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return dao;
	}

	public Boolean regex(String em) {
		Boolean b = false;

		b = Pattern.compile("((?=.*[a-z])(?=.*[0-9])(?=.*[A-Z])((?=.*\\W)).{8,15})").matcher(em).matches();
		if (b == true)
			return b;
		else
			return false;

	}

	public int reg_user(bean client) {

		try {
			ResultSet rs = data.getrs("select username,passwords from Authentication where username='" + client.getUsername() + "'");
			if (rs.next()) {
				return 1;
			} else {
				if (regex(client.getPassword())) {
					PreparedStatement rs1 = (PreparedStatement) data.getps("insert into  Authentication values('"
							+ client.getUsername() + "','" + client.getPassword() + "','EndUser')");
					return 0;
				} else {
					return 2;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 3;
	}

	public int login(bean client) {
		try {
			ArrayList<TicketCounter.bean> user = login_auth(client);

			for (int i = 0; i < user.size(); i++) {
				if (user.get(i).getUsername().equals(client.getUsername())) {
					//System.out.println(user.get(i).getUsername() + " " + user.get(i).getPassword() + "   " + client.getPassword());
					if (user.get(i).getPassword().equals(client.getPassword())) {
						//System.out.println(user.get(i).getPassword());
						client.setType(user.get(i).getType());
						flag = 1;

						break;
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (flag == 0) {
			// System.out.println("flag block");
			return 0;

		} else {
			if (client.getType().equals("ServiceEngineer")) {
				return 1;
			} else if (client.getType().equals("EndUser")) {
				return 2;
			}
			return 0;
		}
	}

	public void register(String uname, String pwd) {
		// TODO Auto-generated method stub

	}
}
