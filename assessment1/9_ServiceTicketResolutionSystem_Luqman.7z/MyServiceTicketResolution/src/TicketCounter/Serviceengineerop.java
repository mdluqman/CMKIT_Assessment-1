package TicketCounter;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.http.HttpSession;

import com.mysql.fabric.xmlrpc.base.Array;
import com.mysql.jdbc.PreparedStatement;

public class Serviceengineerop {
	DAO data = new DAO();

	public ArrayList<TicketCounter.EndUserbean> respond(TicketCounter.EndUserbean eb) {
		// TODO Auto-generated method stub
		ResultSet rs1 = null;
		ArrayList<TicketCounter.EndUserbean> dao = new ArrayList<>();
		try {
			// System.out.println("hi '"+eb.getUsername()+"'");
			rs1 = data.getrs(
					"select * from TicketHolder where seid = (select seid from ServiceEngineerData where username='"
							+ eb.getUsername() + "')");
			while (rs1.next()) {
				String bd = null;
				String cd = null;

				// rs1.getDate(8).toString(),rs1.getDate(9).toString()
				if (rs1.getDate(8) == null && rs1.getDate(9) == null) {
					bd = "";
					cd = "";
				dao.add(new TicketCounter.EndUserbean(rs1.getString(1), rs1.getString(2), rs1.getString(3),
						rs1.getString(4), rs1.getString(5), rs1.getDate(6).toString(), rs1.getDate(7).toString(), bd,
						cd, rs1.getString(10), rs1.getString(11), rs1.getString(12)));
				}
				else if(rs1.getDate(8) != null && rs1.getDate(9)==null)
				{
					cd = "";
					dao.add(new TicketCounter.EndUserbean(rs1.getString(1), rs1.getString(2), rs1.getString(3),
							rs1.getString(4), rs1.getString(5), rs1.getDate(6).toString(), rs1.getDate(7).toString(), rs1.getDate(8).toString(),
							cd, rs1.getString(10), rs1.getString(11), rs1.getString(12)));
				}
				else
				{
					dao.add(new TicketCounter.EndUserbean(rs1.getString(1), rs1.getString(2), rs1.getString(3),
							rs1.getString(4), rs1.getString(5), rs1.getDate(6).toString(), rs1.getDate(7).toString(), rs1.getDate(8).toString(),
							rs1.getDate(9).toString(), rs1.getString(10), rs1.getString(11), rs1.getString(12)));
				}
			}		
		} catch (Exception e) {
			e.printStackTrace();
		}
		return dao;
	}

	public void changestat(String k, String s,TicketCounter.EndUserbean eb) {
		// TODO Auto-generated method stub
		java.util.Date date = new java.util.Date();
		java.sql.Date sqlDate = new java.sql.Date(date.getTime());
		System.out.println(k + " " + s);
		String seid;
		try {
			ResultSet rs = data.getrs("select Stats,seid from TicketHolder where TicketId='" + k + "'");
			rs.next();
			seid = rs.getString(2);
			if (s.equals("WorkInProgress") && rs.getString(1).equals("New")) {
				PreparedStatement res1 = (PreparedStatement) data
						.getps("update TicketHolder set Stats='WorkInProgress',BeginDate='" + sqlDate + "' where seid='"
								+ seid + "' and TicketId='" + k + "'");
				eb.setBd(sqlDate.toString());
//				System.out.println("New to wop hogaya");
			} else if (s.equals("Waiting") && rs.getString(1).equals("New")) {
				PreparedStatement res1 = (PreparedStatement) data
						.getps("update TicketHolder set Stats='Waiting' where seid='" + rs.getString(2)
								+ "' and TicketId='" + k + "'");
//				System.out.println("New to wop hogaya");
				ResultSet rs1 = data.getrs(
						"select TicketId from TicketHolder  where seid='" + rs.getString(2) + "' and Stats='Waiting'");
				if (rs1.next()) {
//					ResultSet rs6=data.getrs("select TotalTickets  from ServiceEngineerData where seid='"+rs.getString(2)+"'");
//					rs6.next();
//					int b=rs.getInt(1)+1;
					PreparedStatement res3 = (PreparedStatement) data
							.getps("update Ticketholder set Stats='New' where TicketId='" + rs1.getString(1) + "'");
					PreparedStatement res4 = (PreparedStatement) data
							.getps("update ServiceEngineerData set CHPTicketId='" + rs1.getString(1) + "'  where seid='"
									+ rs.getString(2) + "'");
				}
			} else if (s.equals("Completed") && rs.getString(1).equals("WorkInProgress")) {

				PreparedStatement res1 = (PreparedStatement) data.getps("update TicketHolder set Stats='Completed',EndDate='" + sqlDate + "' where seid='"+ rs.getString(2) + "' and TicketId='" + k + "' ");
				eb.setRcd(sqlDate.toString());
				ResultSet rs1 = data.getrs("select TicketId from TicketHolder  where seid='" + rs.getString(2) + "' and Stats='Waiting'");
				if (rs1.next()) {
					ResultSet rs6 = data.getrs("select TotalTickets,Pending  from ServiceEngineerData where seid='"+ rs.getString(2) + "'");
					rs6.next();
					int l = rs6.getInt(2) - 1;
					int b = rs6.getInt(1) + 1;
					System.out.println(b + " " + rs1.getString(1));
					PreparedStatement res3 = (PreparedStatement) data
							.getps("update Ticketholder set Stats='New' where TicketId='" + rs1.getString(1) + "'");
					PreparedStatement res4 = (PreparedStatement) data.getps(
							"update ServiceEngineerData set CHPTicketId='" + rs1.getString(1) + "' , TotalTickets = '"
									+ b + "',Pending='" + l + "' where seid='" + rs.getString(2) + "'");
				} else {
					ResultSet rs2 = data.getrs("select TicketId from TicketHolder  where seid='" + rs.getString(2)
							+ "' and stats='Pending'");
					if (rs2.next()) {
						PreparedStatement res3 = (PreparedStatement) data
								.getps("update Ticketholder set stats='New' where TicketId='" + rs2.getString(1) + "'");
						PreparedStatement res4 = (PreparedStatement) data
								.getps("update ServiceEngineerData set CHPTicketId='" + rs2.getString(1)
										+ "' where seid='" + rs.getString(2) + "'");
						ResultSet rs3 = data.getrs("select Pending,TotalTickets  from ServiceEngineerData where seid='"
								+ rs.getString(2) + "'");
						rs3.next();
						int j = rs3.getInt(1) - 1;
						int f = rs3.getInt(2) + 1;
						PreparedStatement res5 = (PreparedStatement) data
								.getps("update ServiceEngineerData set Pending='" + j + "',TotalTickets='" + f
										+ "' where seid='" + rs.getString(2) + "'");
					} else {
						ResultSet rs8 = data.getrs("select TotalTickets from ServiceEngineerData where seid='"+ rs.getString(2) + "'");
						rs8.next();
						int o = rs8.getInt(1) + 1;
						System.out.println(o);
						PreparedStatement res0 = (PreparedStatement) data.getps("update ServiceEngineerData set CHPTicketId='0',TotalTickets = '"+ o + "'where seid='" + rs.getString(2) + "'");
					}
				}
				// PreparedStatement res2=(PreparedStatement) data.getps("update TicketHolder
				// set stats='Completed',EndDate='"+sqlDate+"' ");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void changeprio(String k, String p) {
		// TODO Auto-generated method stub
		try {
			PreparedStatement res = (PreparedStatement) data
					.getps("update TicketHolder set Priority='" + p + "' where TicketId='" + k + "'");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public String[] report() {
		// TODO Auto-generated method stub
		try {
			ResultSet rs1 = data.getrs(
					"select AVG(TIMESTAMPDIFF(day, BeginDate, EndDate)) from TicketHolder where Stats='Completed' and Priority=3");
			ResultSet rs2 = data.getrs(
					"select AVG(TIMESTAMPDIFF(day, BeginDate, EndDate)) from TicketHolder where Stats='Completed' and Priority=2");
			ResultSet rs3 = data.getrs(
					"select AVG(TIMESTAMPDIFF(day, BeginDate, EndDate)) from TicketHolder where Stats='Completed' and Priority=1");
			rs1.next();
			rs2.next();
			rs3.next();
			String h = rs1.getString(1);
			String m = rs2.getString(1);
			String l = rs3.getString(1);
			String[] Array = new String[] { h, m, l };
			return Array;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public ArrayList<String> reportSE() {
		// TODO Auto-generated method stub
		try {
//			String[] Array;

			ArrayList<String> ar = new ArrayList<String>();

			ResultSet rs = data.getrs("select username,seid from ServiceEngineerData");
			while (rs.next()) {
				ResultSet rs1 = data.getrs(
						"select AVG(TIMESTAMPDIFF(day, BeginDate, EndDate)) from TicketHolder where Stats='Completed' and seid='"
								+ rs.getString(2) + "'");
				if (rs1.next()) {
					ar.add(rs.getString(1));
					ar.add(rs1.getString(1));
				}
			}
			return ar;

		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public ArrayList<String> avgage(String uname) {
		// TODO Auto-generated method stub
		try {
//			String[] Array;
			java.util.Date date = new java.util.Date();
			java.sql.Date sqlDate = new java.sql.Date(date.getTime());
			ArrayList<String> ar = new ArrayList<String>();
            System.out.println(uname);
            ResultSet rs5=data.getrs("select seid from ServiceEngineerData where username='"+uname+"'");
            rs5.next();
			ResultSet rs = data.getrs("select TissueDate,TicketId from TicketHolder where Stats!='Completed' and seid='"+rs5.getString(1)+"' ");
			while (rs.next()) {
				ResultSet rs1 = data.getrs("select TIMESTAMPDIFF(day, '" + rs.getDate(1) + "', '" + sqlDate + "') ");
				if (rs1.next()) {
					ar.add(rs.getString(2));
					ar.add(rs1.getString(1));
				}
			}
			return ar;

		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}

}
