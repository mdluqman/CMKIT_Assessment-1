package TicketCounter;

import java.sql.Date;

public class EndUserbean {
	private String SEid;
	private String username;
	private String Tid;
	private String dept;
	private String type;
	private String subject;
	private String ws;
	private String stat;
	private String priority;
	private String Tissued;
	private String red;
	private String bd;
	private String rcd;
	public EndUserbean(String SEeid, String Tid, String dept, String stat, String priority, String Tissued,
			String red, String bd, String rcd, String username,String subject,String ws) {
		// TODO Auto-generated constructor stub
		this.SEid = SEeid;
		this.Tid = Tid;
		this.dept = dept;
		this.stat = stat;
		this.priority = priority;
		this.Tissued = Tissued;
		this.red = red;
		this.bd = bd;
		this.rcd = rcd;
		this.username = username;
		this.subject = subject;
		this.ws = ws;
	}
	public EndUserbean() {
		// TODO Auto-generated constructor stub
	}
	public String getTissued() {
		return Tissued;
	}
	public void setTissued(String tissued) {
		this.Tissued = tissued;
	}
	public String getRed() {
		return red;
	}
	public void setRed(String red) {
		this.red = red;
	}
	public String getSEid() {
		return SEid;
	}
	public void setSEid(String sEid) {
		this.SEid = sEid;
	}
	public String getTid() {
		return Tid;
	}
	public void setTid(String tid) {
		this.Tid = tid;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getWs() {
		return ws;
	}
	public void setWs(String ws) {
		this.ws = ws;
	}
	public String getPriority() {
		return priority;
	}
	public void setPriority(String priority) {
		this.priority = priority;
	}
	public String getRcd() {
		return rcd;
	}
	public void setRcd(String rcd) {
		this.rcd = rcd;
	}
	public String getStat() {
		return stat;
	}
	public void setStat(String stat) {
		this.stat = stat;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getBd() {
		return bd;
	}
	public void setBd(String bd) {
		this.bd = bd;
	}

}
